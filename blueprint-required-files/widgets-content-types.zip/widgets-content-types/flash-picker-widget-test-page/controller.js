<import resource="classpath:alfresco/templates/webscripts/org/craftercms/cstudio/common/lib/common-lifecycle-api.js">
controller = (controller) ? controller : {};
controller.execute();